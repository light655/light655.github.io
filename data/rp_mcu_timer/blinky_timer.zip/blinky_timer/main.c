#include <stdio.h>
#include "hardware/gpio.h"
#include "pico/stdlib.h"

#define LED_PIN 25

volatile bool print_flag = false;

bool blink_timer_callback(__unused struct repeating_timer *t);
bool print_timer_callback(__unused struct repeating_timer *t);

int main(void) {
    stdio_init_all();

    gpio_init(LED_PIN);
    gpio_set_dir(LED_PIN, GPIO_OUT);

    struct repeating_timer blink_timer;
    struct repeating_timer print_timer;
    add_repeating_timer_ms(-2000, blink_timer_callback, NULL, &blink_timer);
    add_repeating_timer_ms(-3000, print_timer_callback, NULL, &print_timer);

    while(1) {
        if(print_flag) {
            puts("Printing something every 3 seconds.");
            print_flag = false;
        }
    }
}

bool blink_timer_callback(__unused struct repeating_timer *t) {
    gpio_xor_mask(1 << LED_PIN);
    return true;
}

bool print_timer_callback(__unused struct repeating_timer *t) {
    print_flag = true;
    return true;
}